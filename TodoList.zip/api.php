<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// OPTIONS 요청 처리
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// result 폴더가 없으면 생성
$resultDir = __DIR__ . '/result';
if (!file_exists($resultDir)) {
    mkdir($resultDir, 0755, true);
}

// 요청 메서드와 액션 확인
$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

// POST 데이터 받기
$input = json_decode(file_get_contents('php://input'), true);

// 날짜 파라미터
$date = $_GET['date'] ?? $input['date'] ?? '';

// 응답 함수
function sendResponse($success, $data = null, $message = '') {
    echo json_encode([
        'success' => $success,
        'data' => $data,
        'message' => $message
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// 할 일 가져오기
if ($method === 'GET' && $action === 'get') {
    if (empty($date)) {
        sendResponse(false, null, '날짜가 필요합니다.');
    }
    
    $filePath = $resultDir . '/' . $date . '.json';
    
    if (file_exists($filePath)) {
        $content = file_get_contents($filePath);
        $todos = json_decode($content, true);
        sendResponse(true, $todos ? $todos : []);
    } else {
        sendResponse(true, []);
    }
}

// 할 일 저장하기
if ($method === 'POST' && $action === 'save') {
    if (empty($date)) {
        sendResponse(false, null, '날짜가 필요합니다.');
    }
    
    if (!isset($input['todos']) || !is_array($input['todos'])) {
        sendResponse(false, null, '할 일 데이터가 필요합니다.');
    }
    
    $filePath = $resultDir . '/' . $date . '.json';
    $todos = $input['todos'];
    
    // JSON 파일로 저장
    $result = file_put_contents($filePath, json_encode($todos, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    
    if ($result !== false) {
        sendResponse(true, $todos, '저장되었습니다.');
    } else {
        sendResponse(false, null, '저장에 실패했습니다.');
    }
}

// 모든 날짜의 할 일 개수 가져오기 (캘린더용)
if ($method === 'GET' && $action === 'getCounts') {
    $month = $_GET['month'] ?? ''; // YYYY-MM 형식
    
    if (empty($month)) {
        sendResponse(false, null, '월 정보가 필요합니다.');
    }
    
    $counts = [];
    $files = glob($resultDir . '/' . $month . '-*.json');
    
    foreach ($files as $file) {
        $filename = basename($file, '.json');
        $content = file_get_contents($file);
        $todos = json_decode($content, true);
        $count = is_array($todos) ? count($todos) : 0;
        $counts[$filename] = $count;
    }
    
    sendResponse(true, $counts);
}

// 최근 할 일 목록 가져오기
if ($method === 'GET' && $action === 'getRecent') {
    $recentFile = $resultDir . '/recent_todos.json';
    
    // 파일이 없으면 빈 배열로 초기화된 파일 생성
    if (!file_exists($recentFile)) {
        $initialData = [];
        file_put_contents($recentFile, json_encode($initialData, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
        sendResponse(true, []);
        exit;
    }
    
    // 파일 읽기
    $content = @file_get_contents($recentFile);
    if ($content === false) {
        // 파일 읽기 실패 시 빈 배열 반환
        sendResponse(true, []);
        exit;
    }
    
    $recent = json_decode($content, true);
    
    // JSON 파싱 실패 시 빈 배열로 초기화
    if (!is_array($recent)) {
        $recent = [];
        file_put_contents($recentFile, json_encode($recent, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    }
    
    sendResponse(true, $recent);
}

// 최근 할 일 목록 저장하기
if ($method === 'POST' && $action === 'saveRecent') {
    if (!isset($input['text']) || empty($input['text'])) {
        sendResponse(false, null, '할 일 텍스트가 필요합니다.');
    }
    
    $recentFile = $resultDir . '/recent_todos.json';
    $newText = trim($input['text']);
    
    // 기존 목록 불러오기
    $recent = [];
    if (file_exists($recentFile)) {
        $content = @file_get_contents($recentFile);
        if ($content !== false) {
            $recent = json_decode($content, true);
            if (!is_array($recent)) {
                $recent = [];
            }
        }
    }
    
    // 중복 제거 (같은 텍스트가 있으면 제거)
    $recent = array_values(array_filter($recent, function($item) use ($newText) {
        return $item !== $newText;
    }));
    
    // 새 항목을 맨 앞에 추가
    array_unshift($recent, $newText);
    
    // 최대 10개만 유지
    $recent = array_slice($recent, 0, 10);
    
    // 배열 인덱스 재정렬
    $recent = array_values($recent);
    
    // JSON 형식으로 저장
    $jsonData = json_encode($recent, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    
    // 저장 시도
    $result = @file_put_contents($recentFile, $jsonData);
    
    if ($result !== false) {
        sendResponse(true, $recent, '저장되었습니다.');
    } else {
        // 저장 실패 시에도 현재 메모리의 데이터 반환
        sendResponse(true, $recent, '저장에 실패했지만 목록은 업데이트되었습니다.');
    }
}

// 기본 응답
sendResponse(false, null, '잘못된 요청입니다.');

